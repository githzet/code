    1  ifconfig
    2  ping www.baidu.com
    3  sudo apt install net-tools
    4  ifconfig
    5  sudo apt install git
    6  sudo apt install vim
    7  git --version
    8  ls
    9  git config --global user.name 黄泽涛
   10  git config user.name
   11  git config --global user.email 892142433@qq.com
   12  git config user.email
   13  ls
   14  git config --global user.name hzet
   15  git config user.name
   16  git config user.email
   17  cd ~
   18  git clone https://github.com/githzet/code.git
   19  ls
   20  cd code
   21  ls
   22  cd ..
   23  ls
   24  history
   25  history>day1_hzet
